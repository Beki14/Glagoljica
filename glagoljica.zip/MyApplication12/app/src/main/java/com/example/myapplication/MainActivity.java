package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    EditText editText;
    Button pijevodButton;
    TextView prevedenTextView;

    // Mapiranje latiničnih slova na glagoljicu
    private static final Map<Character, String> glagoljicaMap = new HashMap<>();

    static {
        glagoljicaMap.put('a', "Ⰰ");
        glagoljicaMap.put('b', "Ⰱ");
        glagoljicaMap.put('c', "Ⰲ");
        glagoljicaMap.put('č', "Ⰳ");
        glagoljicaMap.put('ć', "Ⰴ");
        glagoljicaMap.put('d', "Ⰵ");
        glagoljicaMap.put('đ', "Ⰶ");
        glagoljicaMap.put('e', "Ⰷ");
        glagoljicaMap.put('f', "Ⰸ");
        glagoljicaMap.put('g', "Ⰹ");
        glagoljicaMap.put('h', "Ⰺ");
        glagoljicaMap.put('i', "Ⰻ");
        glagoljicaMap.put('j', "Ⰼ");
        glagoljicaMap.put('k', "Ⰽ");
        glagoljicaMap.put('l', "Ⰾ");
        glagoljicaMap.put('m', "Ⱀ");
        glagoljicaMap.put('n', "Ⱁ");
        glagoljicaMap.put('o', "Ⱃ");
        glagoljicaMap.put('p', "Ⱄ");
        glagoljicaMap.put('r', "Ⱅ");
        glagoljicaMap.put('s', "Ⱆ");
        glagoljicaMap.put('š', "Ⱇ");
        glagoljicaMap.put('t', "Ⱈ");
        glagoljicaMap.put('u', "Ⱉ");
        glagoljicaMap.put('v', "Ⱊ");
        glagoljicaMap.put('z', "Ⱋ");
        glagoljicaMap.put('ž', "Ⱌ");
        glagoljicaMap.put('A', "Ⱍ");
        glagoljicaMap.put('B', "Ⱎ");
        glagoljicaMap.put('C', "Ⱏ");
        glagoljicaMap.put('Č', "Ⱐ");
        glagoljicaMap.put('Ć', "Ⱑ");
        glagoljicaMap.put('D', "Ⱒ");
        glagoljicaMap.put('Đ', "Ⱓ");
        glagoljicaMap.put('E', "Ⱔ");
        glagoljicaMap.put('F', "Ⱕ");
        glagoljicaMap.put('G', "Ⱖ");
        glagoljicaMap.put('H', "Ⱗ");
        glagoljicaMap.put('I', "Ⱘ");
        glagoljicaMap.put('J', "Ⱙ");
        glagoljicaMap.put('K', "Ⱚ");
        glagoljicaMap.put('L', "Ⱛ");
        glagoljicaMap.put('M', "Ⱝ");
        glagoljicaMap.put('N', "Ⱞ");
        glagoljicaMap.put('O', "ⰰ");
        glagoljicaMap.put('P', "ⰱ");
        glagoljicaMap.put('R', "ⰲ");
        glagoljicaMap.put('S', "ⰳ");
        glagoljicaMap.put('Š', "ⰴ");
        glagoljicaMap.put('T', "ⰵ");
        glagoljicaMap.put('U', "ⰶ");
        glagoljicaMap.put('V', "ⰷ");
        glagoljicaMap.put('Z', "ⰸ");
        glagoljicaMap.put('Ž', "ⰹ");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText);
        pijevodButton = findViewById(R.id.prijevodButton);
        prevedenTextView = findViewById(R.id.prevedenTextView);

        pijevodButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputText = editText.getText().toString();
                String translated = PrevediUGlagoljicu(inputText);
                prevedenTextView.setText(translated);
            }
        });
    }

    private String PrevediUGlagoljicu(String text) {
        StringBuilder glagoliticText = new StringBuilder();
        for (char c : text.toCharArray()) {
            if (glagoljicaMap.containsKey(c)) {
                glagoliticText.append(glagoljicaMap.get(c));
            }
        }
        return glagoliticText.toString();
    }
}
